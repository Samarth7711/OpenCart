# flipkart-automation-selenium
To automate a real-world web application
